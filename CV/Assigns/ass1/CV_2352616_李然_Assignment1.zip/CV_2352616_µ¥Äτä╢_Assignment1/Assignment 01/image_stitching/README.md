# Image Stitching

## Introduction

Image stitching is the process of combining multiple photographic images with overlapping fields of view to produce a segmented panorama or high-resolution image. This assignment involves implementing an image stitching algorithm using ORB feature detection, brute-force matching, homography estimation, and image warping techniques.

## Prerequisites

### Install CMake and OpenCV

Make sure you have CMake and OpenCV installed on your system. You can download OpenCV from [OpenCV Releases](https://opencv.org/releases/) and follow the installation instructions for your operating system.

### Build the Project

```bash
mkdir build
cd build
cmake ..
make
```

## Run the Code

```bash
./image_stitching <image1> <image2>
```

Replace `<image1>` and `<image2>` with the paths to the images you want to stitch together.

For example:

```bash
./image_stitching ./Image01.bmp ./Image02.bmp
```

This will generate a stitched image named `Result.png` and a matches visualization named `Matches.png` in the directory where you run the command.

## Example Results

<div style="page-break-after: always;"></div>

### Result 01: Campus Images

Original Images:

<div align="center">
    <img src="./images/Example 01/Image01.bmp" alt="Image 01" style="float:left; width:auto; height:190px;">
    <img src="./images/Example 01/Image02.bmp" alt="Image 02" style="float:right; width:auto; height:190px;">
</div>

Matches Visualization:

![Matches Visualization](./images/Example%2001/Matches.png)

Stitched Image

![Stitched Image](./images/Example%2001/Result.png)

<div style="page-break-after: always;"></div>

### Result 02: Combining Multiple Images

Original Images:

<div style="display:flex; gap:1%; justify-content:space-between; align-items:flex-start; flex-wrap:wrap;">
    <img src="./images/Example 02/Image01.jpg" alt="Image 01" style="width:32%; height:auto;">
    <img src="./images/Example 02/Image02.jpg" alt="Image 02" style="width:32%; height:auto;">
    <img src="./images/Example 02/Image03.jpg" alt="Image 03" style="width:32%; height:auto;">
</div>

Matches Visualization:

<div align="center">
    <img src="./images/Example 02/Matches Temp.png" alt="Matches 3 and 2" style="float:left; width:auto; height:140px;">
    <img src="./images/Example 02/Matches Final.png" alt="Matches 1 and 2" style="float:right; width:auto; height:140px;">
</div>

Stitched Images:

<div align="center">
    <img src="./images/Example 02/Result Temp.png" alt="Intermediate Stitched Image" style="float:left; width:auto; height:180px;">
    <img src="./images/Example 02/Result Final.png" alt="Final Stitched Image" style="float:right; width:auto; height:180px;">
</div>
