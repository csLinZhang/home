#include <algorithm>
#include <chrono>
#include <cstddef>
#include <opencv2/calib3d.hpp>
#include <opencv2/features2d.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/opencv.hpp>
#include <opencv2/photo.hpp>
#include <print>
#include <vector>

void CombineImages(const cv::Mat& image01, const cv::Mat& image02,
                   cv::Mat& combined_image, const cv::Mat& homography) {
  //  Get corners of image01 and transform them with homography.
  std::vector<cv::Point2f> corners01 = {
      cv::Point2f(0, 0), cv::Point2f(image01.cols, 0),
      cv::Point2f(image01.cols, image01.rows), cv::Point2f(0, image01.rows)};

  std::vector<cv::Point2f> warped_corners01;
  cv::perspectiveTransform(corners01, warped_corners01, homography);

  // Get corners of image02.
  std::vector<cv::Point2f> corners02 = {
      cv::Point2f(0, 0), cv::Point2f(image02.cols, 0),
      cv::Point2f(image02.cols, image02.rows), cv::Point2f(0, image02.rows)};

  // Combine all corners to find overall bounding box.
  std::vector<cv::Point2f> all_corners = warped_corners01;
  all_corners.insert(all_corners.end(), corners02.begin(), corners02.end());

  // Find min/max coordinates.
  float min_x = std::min_element(all_corners.begin(), all_corners.end(),
                                 [](const cv::Point2f& a,
                                    const cv::Point2f& b) { return a.x < b.x; })
                    ->x;
  float min_y = std::min_element(all_corners.begin(), all_corners.end(),
                                 [](const cv::Point2f& a,
                                    const cv::Point2f& b) { return a.y < b.y; })
                    ->y;
  float max_x = std::max_element(all_corners.begin(), all_corners.end(),
                                 [](const cv::Point2f& a,
                                    const cv::Point2f& b) { return a.x < b.x; })
                    ->x;
  float max_y = std::max_element(all_corners.begin(), all_corners.end(),
                                 [](const cv::Point2f& a,
                                    const cv::Point2f& b) { return a.y < b.y; })
                    ->y;

  std::println("Bounding box: min=({:.1f},{:.1f}), max=({:.1f},{:.1f})", min_x,
               min_y, max_x, max_y);

  // Create canvas size.
  int canvas_width = static_cast<int>(max_x - min_x);
  int canvas_height = static_cast<int>(max_y - min_y);
  combined_image = cv::Mat::zeros(canvas_height, canvas_width, image01.type());

  // Create translation matrix to handle negative coordinates.
  cv::Mat translation =
      (cv::Mat_<double>(3, 3) << 1, 0, -min_x, 0, 1, -min_y, 0, 0, 1);

  // Warp image01 into canvas with translation.
  cv::warpPerspective(image01, combined_image, translation * homography,
                      cv::Size(canvas_width, canvas_height));

  // Copy image02 into canvas at correct position.
  int offset_x = static_cast<int>(-min_x);
  int offset_y = static_cast<int>(-min_y);

  if (offset_x >= 0 && offset_y >= 0 &&
      offset_x + image02.cols <= canvas_width &&
      offset_y + image02.rows <= canvas_height) {
    cv::Mat roi = combined_image(
        cv::Rect(offset_x, offset_y, image02.cols, image02.rows));
    // Use max operation to avoid overwriting warped pixels.
    cv::max(roi, image02, roi);
  }

  std::println("Canvas size: {}x{}, offset: ({},{})", canvas_width,
               canvas_height, offset_x, offset_y);
}

int main(int argc, char* argv[]) {
  const auto start_time = std::chrono::high_resolution_clock::now();
  std::println("OpenCV Version: {}", CV_VERSION);

  // Check command line arguments.
  if (argc != 3) {
    std::println(stderr, "Usage: {} <image1> <image2>", argv[0]);
    std::println(stderr, "Example: {} Image01.png Image02.png", argv[0]);
    return -1;
  }

  // Load the two campus images.
  cv::Mat image01 = cv::imread(argv[1], cv::IMREAD_COLOR);
  cv::Mat image02 = cv::imread(argv[2], cv::IMREAD_COLOR);

  if (image01.empty() || image02.empty()) {
    std::println(stderr, "Could not load images!");
    return -1;
  }

  std::println("Image 01 size: {}x{}", image01.cols, image01.rows);
  std::println("Image 02 size: {}x{}", image02.cols, image02.rows);

  // Create ORB detector with custom parameters.
  cv::Ptr<cv::ORB> orb = cv::ORB::create(
      1000,  // nfeatures: maximum number of features.
      1.2f,  // scaleFactor: pyramid decimation ratio.
      8,     // nlevels: number of pyramid levels.
      31,    // edgeThreshold: border where features are not detected.
      0,     // firstLevel: first pyramid level.
      2,     // WTA_K: number of points for oriented BRIEF descriptor.
      cv::ORB::HARRIS_SCORE,  // scoreType: HARRIS_SCORE or FAST_SCORE.
      31,                     // patchSize: size of patch used for orientation.
      20                      // fastThreshold: FAST detection threshold.
  );

  // Detect keypoints and compute descriptors for both images.
  std::vector<cv::KeyPoint> keypoints01, keypoints02;
  cv::Mat descriptors01, descriptors02;

  std::println("Detecting ORB features in image 01...");
  orb->detectAndCompute(image01, cv::noArray(), keypoints01, descriptors01);

  std::println("Detecting ORB features in image 02...");
  orb->detectAndCompute(image02, cv::noArray(), keypoints02, descriptors02);

  // Display results.
  std::println("Found {} keypoints in image 01", keypoints01.size());
  std::println("Found {} keypoints in image 02", keypoints02.size());
  std::println("Descriptor size: {} bits", descriptors01.cols);

  // Match descriptors using BFMatcher with Hamming distance.
  cv::BFMatcher matcher(cv::NORM_HAMMING, false);
  std::vector<cv::DMatch> matches;
  matcher.match(descriptors01, descriptors02, matches);
  std::println("Found {} total matches", matches.size());
  std::sort(matches.begin(), matches.end());
  std::println("Top 10 matches after sorting by distance:");
  for (size_t i = 0; i < std::min(matches.size(), size_t(10)); ++i) {
    const cv::DMatch& match = matches[i];
    std::println(
        "matches[{}]: queryIdx={}, trainIdx={}, distance={:.2f}, imgIdx={}", i,
        match.queryIdx, match.trainIdx, match.distance, match.imgIdx);
  }

  // Draw matches.
  std::vector<cv::DMatch> matches_display{
      matches.begin(),
      matches.begin() + static_cast<size_t>(matches.size() * 0.05)};

  cv::Mat img_matches;
  cv::drawMatches(image01, keypoints01, image02, keypoints02, matches_display,
                  img_matches);
  cv::imwrite("Matches.png", img_matches);

  // Compute homography matrix using RANSAC.
  std::vector<cv::Point2f> points01, points02;
  for (const auto& match : matches) {
    points01.push_back(keypoints01[match.queryIdx].pt);
    points02.push_back(keypoints02[match.trainIdx].pt);
  }
  cv::Mat homography = cv::findHomography(points01, points02, cv::RANSAC, 3.0,
                                          cv::noArray(), 2000);

  std::println("Computed homography matrix: ");
  for (int r = 0; r < homography.rows; ++r) {
    for (int c = 0; c < homography.cols; ++c) {
      std::print("{:.4f} ", homography.at<double>(r, c));
    }
    std::println();
  }

  // Warp images using homography matrix.
  cv::Mat warped_image;
  cv::warpPerspective(image01, warped_image, homography, image02.size());
  std::println("Wrapped image size: {}x{}", warped_image.size().width,
               warped_image.size().height);

  // Combine the warped images and the original image.
  cv::Mat combined_image;
  CombineImages(image01, image02, combined_image, homography);
  cv::imwrite("Result.png", combined_image);
  std::println("Combined image created, image size: {}x{}",
               combined_image.size().width, combined_image.size().height);

  const auto end_time = std::chrono::high_resolution_clock::now();
  const std::chrono::duration<double> elapsed = end_time - start_time;
  std::println("Finished in {:.3f} seconds", elapsed.count());

  // Display images.
  cv::imshow("Matches", img_matches);
  cv::waitKey(0);
  cv::imshow("Combined Image", combined_image);
  cv::waitKey(0);

  return 0;
}
