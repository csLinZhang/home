import numpy as np
import matplotlib.pyplot as plt


def fit_line_rasnac(
    data: np.ndarray, n: int, k: int, t: float, d: int
) -> tuple[float, float] | None:
    """
    RANSAC algorithm for line fitting.
    """
    if len(data) < n:
        return None

    # Initialize variables.
    best_model = None
    best_errors = np.inf
    best_inliers = np.zeros(data.shape[0], dtype=bool)

    for _ in range(k):
        # Randomly select n points.
        sample = np.random.choice(data.shape[0], size=n, replace=False)
        sample_points = data[sample]

        # Fit a line to the sample points.
        model = fit_line_two_points(sample_points)
        if model is None:
            continue

        # Calculate distances from all points to the model.
        distances = calculate_distances(data, model)

        # Calcuate the number of inliners.
        inliners = distances < t
        num_inliers = np.sum(inliners)

        # Update best model if consensus set is large enough.
        if num_inliers >= d:
            # Calculate error for inliners.
            error = np.sum(distances[inliners])
            if error < best_errors:
                best_model = model
                best_errors = error
                best_inliers = inliners

    # Final refinement using all inliers.
    if best_model is not None and len(best_inliers) > n:
        best_model = fit_line_least_squares(data[best_inliers])

    return best_model


def fit_line_two_points(points: np.ndarray) -> tuple[float, float] | None:
    """
    Fit a line (y = ax + b) to two points.
    Returns (a, b) coefficients or None if points are vertically aligned.
    """
    if len(points) != 2:
        return None

    x1, y1 = points[0]
    x2, y2 = points[1]

    # Check if points are vertically aligned.
    if abs(x2 - x1) < 1e-10:
        return None

    # Calculate line parameters.
    a = (y2 - y1) / (x2 - x1)
    b = y1 - a * x1

    return a, b


def fit_line_least_squares(
    points: np.ndarray,
) -> tuple[float, float] | None:
    """
    Fit a line (y = ax + b) to a set of points using least squares.
    Returns (a, b) coefficients or None if points are vertically aligned.
    """
    if len(points) < 2:
        return None

    x_coords, y_coords = points.T
    x_sum = np.sum(x_coords)
    y_sum = np.sum(y_coords)
    xy_sum = np.sum(x_coords * y_coords)
    x_squared_sum = np.sum(x_coords**2)

    n = len(points)
    denominator = n * x_squared_sum - x_sum**2
    if abs(denominator) < 1e-10:
        return None

    a = (n * xy_sum - x_sum * y_sum) / denominator
    b = (x_squared_sum * y_sum - x_sum * xy_sum) / denominator

    return a, b


def calculate_distances(
    points: np.ndarray, coefficients: tuple[float, float]
) -> np.ndarray:
    """
    Calculate the distances from a set of points to a line.
    """
    a, b = coefficients
    x_coords, y_coords = points.T
    distances: np.ndarray = np.abs(a * x_coords - y_coords + b) / np.sqrt(a**2 + 1)
    return distances


def visualize_results(
    points: np.ndarray, coefficients: tuple[float, float], threshold: float
) -> None:
    """
    Visualize the results of the RANSAC line fitting.
    """
    a, b = coefficients
    x_coords, y_coords = points.T

    # Calculate distances to determine inliers and outliers.
    distances = calculate_distances(points, coefficients)
    inliers = distances < threshold
    outliers = ~inliers

    # Plot the fitted line and inliers/outliers.
    plt.plot(
        x_coords,
        a * x_coords + b,
        color=(0.85, 0.5, 0.5),
        linewidth=3,
        label="Fitted Line",
    )
    plt.scatter(
        x_coords[inliers],
        y_coords[inliers],
        color=(0.8, 0.75, 0.95),
        s=80,
        label="Inliers",
    )
    plt.scatter(
        x_coords[outliers],
        y_coords[outliers],
        color=(0.95, 0.75, 0.5),
        s=80,
        label="Outliers",
    )
    # Add the equation of the line to the plot.
    equation_text = f"y = {a:.3f}x + {b:.3f}"
    plt.text(
        0.05,
        0.95,
        equation_text,
        transform=plt.gca().transAxes,
        fontsize=16,
        verticalalignment="top",
    )
    plt.legend()
    plt.show()


DATA_POINTS = np.array(
    [
        (-2, 0),
        (0, 0.9),
        (2, 2.0),
        (3, 6.5),
        (4, 2.9),
        (5, 8.8),
        (6, 3.95),
        (8, 5.03),
        (10, 5.97),
        (12, 7.1),
        (13, 1.2),
        (14, 8.2),
        (16, 8.5),
        (18, 10.1),
    ],
    dtype=np.float64,
)


MIN_POINTS_FOR_LINE = 2  # Minimum number of points required for fitting a line.
MAX_ITERATIONS = 1000  # Number of iterations for RANSAC.
DISTANCE_THRESHOLD = 1.0  # Distance threshold for inlier/outlier classification.
MIN_CONSENSUS_SIZE = 10  #  Minimum number of points required for a good consensus set.


if __name__ == "__main__":
    # Example usage
    model = fit_line_rasnac(
        DATA_POINTS,
        MIN_POINTS_FOR_LINE,
        MAX_ITERATIONS,
        DISTANCE_THRESHOLD,
        MIN_CONSENSUS_SIZE,
    )

    if model is not None:
        visualize_results(DATA_POINTS, model, DISTANCE_THRESHOLD)
