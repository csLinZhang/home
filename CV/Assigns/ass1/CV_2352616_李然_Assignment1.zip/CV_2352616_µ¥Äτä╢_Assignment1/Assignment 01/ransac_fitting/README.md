# RANSAC Fitting

## Introduction

This repository contains an implementation of the RANSAC (Random Sample Consensus) algorithm for fitting a line to a set of 2D points. RANSAC is a robust method that can handle a significant proportion of outliers in the data.

## Prerequisites

### Create Virtual Environment

```bash
python -m venv .venv

# Linux/MacOS
source .venv/bin/activate

# Windows
.venv\Scripts\activate
```

### Install Dependencies

```bash
pip install -r requirements.txt
```

or install manually:

```bash
pip install numpy matplotlib
```

## Run the Code

```bash
python ransac_fitting.py
```

This will generate a plot showing the original points, the inliers, and the fitted line.

## Example Results

![RANSAC Fitting Result](./Result.png)
