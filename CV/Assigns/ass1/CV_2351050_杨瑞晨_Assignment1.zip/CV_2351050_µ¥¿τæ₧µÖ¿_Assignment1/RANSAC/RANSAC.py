import numpy as np
import matplotlib.pyplot as plt

def ransac_homography(points, n_iterations=100, threshold=1.0, min_samples=2):
    """
    Fits a 2D line to a set of points using the RANSAC algorithm.
    
    Args:
        points (np.array): A Nx2 array of (x, y) points.
        n_iterations (int): The number of RANSAC iterations.
        threshold (float): The distance threshold to classify inliers.
        min_samples (int): The minimum number of points to define a model (2 for a line).
        
    Returns:
        tuple: A tuple containing:
            - best_model (tuple): The parameters (a, b, c) of the best-fit line ax + by + c = 0.
            - best_inliers (np.array): The indices of the inlier points.
    """
    best_model = None
    best_inliers = []
    num_points = points.shape[0]
    
    if num_points < min_samples:
        raise ValueError("Not enough points to fit a model.")

    for i in range(n_iterations):
        # Randomly sample 'min_samples' points
        sample_indices = np.random.choice(num_points, min_samples, replace=False)
        sample_points = points[sample_indices]
        
        # Fit a model to the sampled points
        p1 = sample_points[0]
        p2 = sample_points[1]
        
        # Line equation: ax + by + c = 0
        # Handle vertical line case
        if p2[0] - p1[0] == 0:
            a, b, c = 1, 0, -p1[0]
        else:
            m = (p2[1] - p1[1]) / (p2[0] - p1[0])
            a, b, c = m, -1, p1[1] - m * p1[0]

        # Find the consensus set (inliers)
        distances = np.abs(a * points[:, 0] + b * points[:, 1] + c) / np.sqrt(a**2 + b**2)
        current_inliers_indices = np.where(distances < threshold)[0]
        
        # Score the model and update if it's the best so far
        if len(current_inliers_indices) > len(best_inliers):
            best_inliers = current_inliers_indices
            best_model = (a, b, c)

    # Refit the model using all inliers from the best model found
    if len(best_inliers) > 0:
        inlier_points = points[best_inliers]
        # Using least squares (np.polyfit) for the final line
        final_m, final_c = np.polyfit(inlier_points[:, 0], inlier_points[:, 1], 1)
        # Convert back to ax+by+c=0 form
        best_model = (final_m, -1, final_c)
    else:
        # Handle case where no inliers were found
        best_model = (0, 0, 0)
        best_inliers = []
        
    return best_model, best_inliers


points = np.array([
    (-2, 0), (0, 0.9), (2, 2.0), (3, 6.5),
    (4, 2.9), (5, 8.8), (6, 3.95), (8, 5.03),
    (10, 5.97), (12, 7.1), (13, 1.2), (14, 8.2),
    (16, 8.5), (18, 10.1)
])

# Run RANSAC
ransac_model, inlier_indices = ransac_homography(points, n_iterations=100, threshold=1.0)

# Identify outliers
all_indices = np.arange(points.shape[0])
outlier_indices = np.setdiff1d(all_indices, inlier_indices)

# --- Visualization ---
plt.figure(figsize=(10, 8))

# Plot inliers
plt.scatter(points[inlier_indices, 0], points[inlier_indices, 1],
            c='limegreen', marker='o', s=60, label='Inliers')

# Plot outliers
plt.scatter(points[outlier_indices, 0], points[outlier_indices, 1],
            c='red', marker='x', s=60, label='Outliers')

# Plot the RANSAC fitted line
a, b, c = ransac_model
x_line = np.linspace(min(points[:, 0]) - 1, max(points[:, 0]) + 1, 100)
# From ax+by+c=0, we get y = (-ax-c)/b
y_line = (-a * x_line - c) / b

plt.plot(x_line, y_line, color='blue', linewidth=2, label='RANSAC Fitted Line')

plt.title('RANSAC Line Fitting')
plt.xlabel('X')
plt.ylabel('Y')
plt.legend()
plt.grid(True)
plt.show()

# Print the final model
final_m = -ransac_model[0]/ransac_model[1]
final_c = -ransac_model[2]/ransac_model[1]
print(f"Final fitted line: y = {final_m:.4f}x + {final_c:.4f}")
print(f"Number of inliers found: {len(inlier_indices)}")