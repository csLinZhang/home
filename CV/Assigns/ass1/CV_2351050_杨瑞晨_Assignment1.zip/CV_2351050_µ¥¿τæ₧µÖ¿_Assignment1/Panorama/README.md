# Panorama Stitcher

This repository contains a simple panorama stitching implementation in C++ using OpenCV, consisting of the following pipeline:

- **ORB** feature detection and descriptor matching
- **RANSAC** to reject outliers (find inlier matches)
- Homography estimation using a custom **Moore-Penrose pseudo-inverse** solver (SVD)
- Warp and stitch images into a panorama

## Generated outputs

- `matches.jpg` – visualization of matches found
- `panorama.jpg` – final stitched panorama image

## Build

```bash
mkdir -p build && cd build
cmake ..
make
```

## Run

From `build`:

```bash
./stitcher <path_to_image1> <path_to_image2>
```

For example:

```bash
./stitcher ../img/img1.jpg ../img/img2.jpg
```

After running you should find `matches.jpg` and `panorama.jpg` in the `img` directory.
