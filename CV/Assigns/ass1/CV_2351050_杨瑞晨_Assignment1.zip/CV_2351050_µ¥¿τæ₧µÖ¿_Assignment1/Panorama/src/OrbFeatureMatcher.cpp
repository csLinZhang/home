#include "OrbFeatureMatcher.h"
#include <iostream>

std::vector<cv::DMatch> detectAndMatchOrbFeatures(const cv::Mat& img1, const cv::Mat& img2,
                            std::vector<cv::KeyPoint>& keypoints1,
                            std::vector<cv::KeyPoint>& keypoints2) 
{
    // Create ORB detector and descriptor
    cv::Ptr<cv::ORB> orb = cv::ORB::create(2000);
    cv::Mat descriptors1, descriptors2;

    // Detect keypoints and compute descriptors
    orb->detectAndCompute(img1, cv::Mat(), keypoints1, descriptors1);
    orb->detectAndCompute(img2, cv::Mat(), keypoints2, descriptors2);

    // Create a Brute Force matcher using Hamming distance
    cv::Ptr<cv::BFMatcher> matcher = cv::BFMatcher::create(cv::NORM_HAMMING);
    std::vector<cv::DMatch> matches;

    // Match descriptors
    matcher->match(descriptors1, descriptors2, matches);

    std::sort(matches.begin(), matches.end(), [](const cv::DMatch& a, const cv::DMatch& b) {
        return a.distance < b.distance;
    });
    return matches;
}