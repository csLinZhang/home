#include "HomographyEstimator.h"
#include <iostream>

cv::Mat computeHomographyWithPseudoInverse(const std::vector<cv::KeyPoint>& keypoints1,
                                           const std::vector<cv::KeyPoint>& keypoints2,
                                           const std::vector<cv::DMatch>& matches) {
    if (matches.size() < 4) {
        std::cerr << "Error: Not enough matches to compute homography. Need at least 4." << std::endl;
        return cv::Mat();
    }

    // Extract the coordinates of the matched points.
    std::vector<cv::Point2f> points1, points2;
    for (const auto& match : matches) {
        points1.push_back(keypoints1[match.queryIdx].pt);
        points2.push_back(keypoints2[match.trainIdx].pt);
    }

    int n_points = points1.size();
    cv::Mat A = cv::Mat::zeros(2 * n_points, 8, CV_64F);
    cv::Mat b = cv::Mat::zeros(2 * n_points, 1, CV_64F);

    // Fill matrices A and b for the linear system Ah = b.
    for (int i = 0; i < n_points; ++i) {
        double x1 = points1[i].x;
        double y1 = points1[i].y;
        double x2 = points2[i].x;
        double y2 = points2[i].y;

        cv::Mat row1 = (cv::Mat_<double>(1, 8) << x2, y2, 1.0, 0, 0, 0, -x1 * x2, -x1 * y2);
        cv::Mat row2 = (cv::Mat_<double>(1, 8) << 0, 0, 0, x2, y2, 1.0, -y1 * x2, -y1 * y2);
        row1.copyTo(A.row(2 * i));
        row2.copyTo(A.row(2 * i + 1));
        b.at<double>(2 * i, 0) = x1;
        b.at<double>(2 * i + 1, 0) = y1;
    }

    // Solve the system h = A_pinv * b, where A_pinv is the pseudo-inverse of A.
    cv::Mat h(8, 1, CV_64F);
    cv::Mat A_pinv;
    // cv::invert with DECOMP_SVD computes the Moore-Penrose pseudo-inverse.
    cv::invert(A, A_pinv, cv::DECOMP_SVD);
    h = A_pinv * b;

    // Reconstruct the 3x3 homography matrix H from the 8x1 vector h.
    cv::Mat H = (cv::Mat_<double>(3, 3) << h.at<double>(0), h.at<double>(1), h.at<double>(2),
                                           h.at<double>(3), h.at<double>(4), h.at<double>(5),
                                           h.at<double>(6), h.at<double>(7), 1.0);

    return H;
}