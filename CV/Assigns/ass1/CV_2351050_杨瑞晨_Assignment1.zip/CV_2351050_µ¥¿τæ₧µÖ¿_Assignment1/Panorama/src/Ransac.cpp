#include "Ransac.h"

#include <iostream>
#include <random>

void findInliersRANSAC(const std::vector<cv::KeyPoint>& keypoints1,
                       const std::vector<cv::KeyPoint>& keypoints2,
                       const std::vector<cv::DMatch>& all_matches,
                       std::vector<cv::DMatch>& inlier_matches,
                       int iterations,
                       double reprojection_threshold)
{
    if (all_matches.size() < 4) {
        return;
    }

    std::vector<cv::DMatch> best_inliers;
    cv::Mat best_H;
    int max_inliers = 0;

    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> distrib(0, all_matches.size() - 1);

    for (int k = 0; k < iterations; ++k) {
        // 1. Randomly sample 4 matches
        std::vector<cv::Point2f> src_pts(4), dst_pts(4);
        std::vector<int> sample_indices;
        while (sample_indices.size() < 4) {
            int idx = distrib(gen);
            if (std::find(sample_indices.begin(), sample_indices.end(), idx) == sample_indices.end()) {
                sample_indices.push_back(idx);
            }
        }

        for (int i = 0; i < 4; ++i) {
            src_pts[i] = keypoints2[all_matches[sample_indices[i]].trainIdx].pt;
            dst_pts[i] = keypoints1[all_matches[sample_indices[i]].queryIdx].pt;
        }

        // 2. Compute a temporary homography from the 4 points
        cv::Mat H_temp = cv::getPerspectiveTransform(src_pts, dst_pts);
        if (H_temp.empty()) {
            continue;
        }

        // 3. Count inliers for this model
        std::vector<cv::DMatch> current_inliers;
        for (const auto& match : all_matches) {
            cv::Point2f pt2 = keypoints2[match.trainIdx].pt;
            cv::Point2f pt1_actual = keypoints1[match.queryIdx].pt;

            std::vector<cv::Point2f> pt2_vec = {pt2};
            std::vector<cv::Point2f> pt1_projected_vec;
            cv::perspectiveTransform(pt2_vec, pt1_projected_vec, H_temp);

            if (cv::norm(pt1_actual - pt1_projected_vec[0]) < reprojection_threshold) {
                current_inliers.push_back(match);
            }
        }

        // 4. Keep the best model found so far
        if (current_inliers.size() > max_inliers) {
            max_inliers = current_inliers.size();
            best_inliers = current_inliers;
        }
    }

    inlier_matches = best_inliers;
    std::cout << "RANSAC found " << inlier_matches.size() << " inliers out of " << all_matches.size() << " matches." << std::endl;
}