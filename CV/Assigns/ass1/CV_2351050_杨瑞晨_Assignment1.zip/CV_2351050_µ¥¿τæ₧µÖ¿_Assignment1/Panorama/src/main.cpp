#include <iostream>
#include "OrbFeatureMatcher.h"
#include "HomographyEstimator.h"
#include "Ransac.h"
#include <opencv2/opencv.hpp>

int main(int argc, char** argv) {
    if (argc != 3) {
        std::cout << "Usage: ./stitcher <path_to_image1> <path_to_image2>" << std::endl;
        return -1;
    }

    // Read input images
    cv::Mat img1 = cv::imread(argv[1]);
    cv::Mat img2 = cv::imread(argv[2]);

    if (img1.empty() || img2.empty()) {
        std::cerr << "Error: Could not open or find the images!" << std::endl;
        return -1;
    }

    // Detect and match ORB features
    std::vector<cv::KeyPoint> keypoints1, keypoints2;
    std::vector<cv::DMatch> matches = detectAndMatchOrbFeatures(img1, img2, keypoints1, keypoints2);

    std::vector<cv::DMatch> inlier_matches;
    findInliersRANSAC(keypoints1, keypoints2, matches, inlier_matches);

    cv::Mat img_matches;
    cv::drawMatches(img1, keypoints1, img2, keypoints2, inlier_matches, img_matches);
    cv::imwrite("../img/matches.jpg", img_matches);

    // Compute homography using Moore-Penrose Pseudo-Inverse
    cv::Mat H = computeHomographyWithPseudoInverse(keypoints1, keypoints2, inlier_matches);
    if (H.empty()) {
        std::cerr << "Error: Homography computation failed." << std::endl;
        return -1;
    }
    std::cout << "Computed Homography Matrix H:\n" << H << std::endl;

    // Find the corners of img2 in the coordinate system of img1
    std::vector<cv::Point2f> corners_img2(4);
    corners_img2[0] = cv::Point2f(0, 0);
    corners_img2[1] = cv::Point2f(img2.cols, 0);
    corners_img2[2] = cv::Point2f(img2.cols, img2.rows);
    corners_img2[3] = cv::Point2f(0, img2.rows);
    std::vector<cv::Point2f> corners_transformed(4);
    cv::perspectiveTransform(corners_img2, corners_transformed, H);

    // Find the bounding box of the stitched image
    float min_x = 0, max_x = img1.cols;
    float min_y = 0, max_y = img1.rows;

    for (size_t i = 0; i < corners_transformed.size(); ++i) {
        min_x = std::min(min_x, corners_transformed[i].x);
        max_x = std::max(max_x, corners_transformed[i].x);
        min_y = std::min(min_y, corners_transformed[i].y);
        max_y = std::max(max_y, corners_transformed[i].y);
    }

    // Create a translation matrix to move the panorama to the positive quadrant
    cv::Mat H_translate = cv::Mat::eye(3, 3, CV_64F);
    if (min_x < 0) H_translate.at<double>(0, 2) = -min_x;
    if (min_y < 0) H_translate.at<double>(1, 2) = -min_y;

    int result_width = static_cast<int>(max_x - min_x);
    int result_height = static_cast<int>(max_y - min_y);

    // Warp img2 using the combined transformation
    cv::Mat result;
    cv::warpPerspective(img2, result, H_translate * H, cv::Size(result_width, result_height));

    // Copy img1 to the correct position in the panorama
    cv::Mat roi = result(cv::Rect(-min_x, -min_y, img1.cols, img1.rows));
    img1.copyTo(roi);

    cv::imwrite("../img/panorama.jpg", result);

    cv::namedWindow("Matches", cv::WINDOW_NORMAL);
    cv::imshow("Matches", img_matches);
    cv::namedWindow("Panorama", cv::WINDOW_NORMAL);
    cv::imshow("Panorama", result);

    cv::waitKey(0);
    return 0;
}