#ifndef HOMOGRAPHY_ESTIMATOR_H
#define HOMOGRAPHY_ESTIMATOR_H

#include <opencv2/core.hpp>
#include <vector>

cv::Mat computeHomographyWithPseudoInverse(const std::vector<cv::KeyPoint>& keypoints1,
                                           const std::vector<cv::KeyPoint>& keypoints2,
                                           const std::vector<cv::DMatch>& matches);

#endif // HOMOGRAPHY_ESTIMATOR_H
