#ifndef RANSAC_H
#define RANSAC_H

#include <opencv2/core.hpp>
#include <opencv2/calib3d.hpp>
#include <opencv2/imgproc.hpp>
#include <vector>

// Performs RANSAC to find the best set of inlier matches for homography estimation.
void findInliersRANSAC(const std::vector<cv::KeyPoint>& keypoints1,
                       const std::vector<cv::KeyPoint>& keypoints2,
                       const std::vector<cv::DMatch>& all_matches,
                       std::vector<cv::DMatch>& inlier_matches,
                       int iterations = 3000,
                       double reprojection_threshold = 3.0);

#endif // RANSAC_H