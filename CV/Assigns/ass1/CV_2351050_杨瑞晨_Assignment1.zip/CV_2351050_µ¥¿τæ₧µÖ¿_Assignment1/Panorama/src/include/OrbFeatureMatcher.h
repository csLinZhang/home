#ifndef ORB_FEATURE_MATCHER_H
#define ORB_FEATURE_MATCHER_H

#include <opencv2/core.hpp>
#include <opencv2/features2d.hpp>

std::vector<cv::DMatch> detectAndMatchOrbFeatures(const cv::Mat& img1, const cv::Mat& img2,
                               std::vector<cv::KeyPoint>& keypoints1,
                               std::vector<cv::KeyPoint>& keypoints2);

#endif // ORB_FEATURE_MATCHER_H
