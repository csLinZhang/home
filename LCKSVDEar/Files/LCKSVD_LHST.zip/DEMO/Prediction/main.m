% Authors:	Lida LI, Lin ZHANG, Hongyu LI
% Date:       Sept. 14, 2014
% Email:      lld533@hotmail.com, cslinzhang@tongji.edu.cn
% VISCOM, School of Software Engineering, Tongji University, Shanghai,
% China.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                       Description
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% This demo shows 3D ear identification by using the proposed Local Histogram Shape Type （LHST） features, and Jiang et al.'s LC-KSVD [1] as the classifier.
%
% [1] Zhuolin Jiang, Zhe Lin, Larry S. Davis, "Learning A Discriminative Dictionary for Sparse Coding via Label Consistent K-SVD", CVPR 2011.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function main()

clear;
clc;

%% Add path of KSVD and OMP
addpath(genpath('/ksvdbox'));
addpath(genpath('/OMPbox'));

%% constant values
projectionMatFileName = 'projectionMat486_360.mat';

%% Load probe and training feature vectors
featsFile = load('gallery_test.mat');

%% Load projection matrix for dimensionality reduction
if exist(projectionMatFileName, 'file')
	load(projectionMatFileName);%projectionMat
else
	% If the projection matrix file does NOT exist, create one.
	projectionMat = createProjectionMat(size(featsFile.test_feats, 1), 360);
end	

%% Conduct dimensionality reduction
[reducedTrainingFeats, reducedTestFeats] = dimensionalityReduction(featsFile.training_feats, featsFile.test_feats, projectionMat);

%% Run LC-KSVD
runLCKSVD(8, 1, 1, reducedTrainingFeats, reducedTestFeats, featsFile.training_label, featsFile.test_label);

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%			Local Function : dimensionalityReduction
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% DIMENSIONALITYREDUCTION reduces the dimensionality of the training features matrix as well as the test features matrix using a random projection matrix, which is of white gaussian noise.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%					Input Arguments
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% trainingFeats			- training features matrix
% testFeats				- test features matrix
% projectionMat			- random projection matrix
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%					Output Arguments
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% lowDimTrainingFeats	- training features matrix in lower dimensionality space
% lowDimTestFeats		- test features matrix in lower dimensionality space
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [lowDimTrainingFeats, lowDimTestFeats] = dimensionalityReduction(trainingFeats, testFeats, projectionMat)

% project training features and test features into lower dimensionality space
lowDimTrainingFeats = projectionMat' * trainingFeats;
lowDimTestFeats = projectionMat' * testFeats;

end