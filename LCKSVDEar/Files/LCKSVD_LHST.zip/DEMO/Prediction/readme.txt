Authors:	Lida LI, Lin ZHANG, Hongyu LI
Date:		Oct. 4, 2014
Email:		lld533@hotmail.com, cslinzhang@tongji.edu.cn
VISCOM, School of Software Engineering, Tongji University, Shanghai,China.

1. This demo shows 3D ear identification by using the proposed Local Histogram Shape Type ��LHST�� features, and Jiang et al.'s LC-KSVD (*) as the classifier. The classifier is based on the sharing code (**).

2. All the gallery samples in subset3 of UND-J2 benchmark dataset are used for training and all the test samples in the same subset will be predicted.

3. To obtain an LHST feature vector, the ROI, a 96x65 normalized range image, is split into 9 segments by row and 6 segments by column in uniform. Each patch is 10 pixels by 10 pixels. Thus, the dimensionality of a LHST feature vector is:
9(segments/row) x 6(segments/column) x 9(bins of histogram/patch) = 486.

4. To fit an LHST feature vector to LC-KSVD, the dimensionality of the vector is reduced to 360 by using a random projection matrix. In this demo, the matrix in projectionMat486_360.mat is used. If the .MAT file is missing, the demo tries to create one by calling createProjectionMat.m.

5. For LC-KSVD, sparsity threshold, square root alpha and square root beta are set to 8, 1, 1, respectively.

6. Run main.m to start identifying the ears. It will print the following two lines (***) in Matlab:

Final recognition rate for LC-KSVD1 is : 0.9622 
Final recognition rate for LC-KSVD2 is : 0.9828

-----------------------------------------------------
(*)	Zhuolin Jiang, Zhe Lin, Larry S. Davis, "Learning A Discriminative Dictionary for Sparse Coding via Label Consistent K-SVD", CVPR 2011.
(**)	The sharing codes are available via http://www.umiacs.umd.edu/~zhuolin/projectlcksvd.html
(***)	The results are promised if the projectionMat.mat in the folder is used. If you happen to call createProjectionMat.m to generate a random projection matrix and reduce the dimensionality of the feature vectors with it, the results may have little bias.