% Authors:	Lida LI, Lin ZHANG, Hongyu LI
% Date:       Oct. 3, 2014
% Email:      lld533@hotmail.com, cslinzhang@tongji.edu.cn
% VISCOM, School of Software Engineering, Tongji University, Shanghai,
% China.

function projectionMat = createProjectionMat(higherDim, lowerDim)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%					Description							%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% createProjectionMat creates a random projection matrix P.
% Denote M a feature matrix where each column M(:,i) is a 
% feature vector in a higher dimensional space, and N a 
% feature matrix where each column N(:,i) is the feature 
% vector of M(:,i) in a lower dimensional space. 
% We have N = P'M.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%					Input Arguments						 %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% -higherDim	the dimension of a original feature vector
% -lowerDim		the dimension of a dimensionality reduced
%               feature vector
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%					Output Arguments					 %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% -projectionMat higherDim*lowerDim projection matrix
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
projectionMat = wgn(higherDim, lowerDim,  1);

for i=1:size(projectionMat, 2)

    projectionMat(:, i) = projectionMat(:,i) / norm(projectionMat(:,i));

end

end