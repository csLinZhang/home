function [prediction1, accuracy1, training_time1, classification_time1, prediction2, accuracy2, training_time2, classification_time2] = runLCKSVD(sparsitythres, sqrt_alpha, sqrt_beta, training_feats, test_feats, training_label, test_label)

%% constant
iterations = 50; % iteration number
iterations4ini = 20; % iteration number for initialization

%% dictionary learning process
% get initial dictionary Dinit and Winit
dictsize = size(training_feats, 2); % dictionary size
[Dinit,Tinit,Winit,Q_train] = initialization4LCKSVD(training_feats,training_label,dictsize,iterations4ini,sparsitythres);

% run LC K-SVD Training (reconstruction err + class penalty)
tic;
[D1,X1,T1,W1] = labelconsistentksvd1(training_feats,Dinit,Q_train,Tinit,training_label,iterations,sparsitythres,sqrt_alpha);
training_time1 = toc;

% run LC k-svd training (reconstruction err + class penalty + classifier err)
tic;
[D2,X2,T2,W2] = labelconsistentksvd2(training_feats,Dinit,Q_train,Tinit,training_label,Winit,iterations,sparsitythres,sqrt_alpha,sqrt_beta);
training_time2 = toc;

%% classification process
tic;
[prediction1,accuracy1] = classification(D1, W1, test_feats, test_label, sparsitythres);
fprintf('Final recognition rate for LC-KSVD1 is : %.04f \n', accuracy1);
classification_time1 = toc;

tic;
[prediction2,accuracy2] = classification(D2, W2, test_feats, test_label, sparsitythres);
fprintf('Final recognition rate for LC-KSVD2 is : %.04f\n ', accuracy2);
classification_time2 = toc;

end