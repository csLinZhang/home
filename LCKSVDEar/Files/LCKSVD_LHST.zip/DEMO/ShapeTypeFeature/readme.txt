Authors:	Lida LI, Lin ZHANG, Hongyu LI
Date:		Oct. 4, 2014
Email:		lld533@hotmail.com, cslinzhang@tongji.edu.cn
VISCOM, School of Software Engineering, Tongji University, Shanghai,China.

1. This demo demonstrate the procedures of generating a Local Histogram Shape Type (LHST) feature vector for an ROI range image.

2. Run main.m to generate LHST feature vector for 1sm.jpg and save the result to "shapeIndexFeatureVector.mat", the variable name of the result is "shapeIndexFeatureVector".