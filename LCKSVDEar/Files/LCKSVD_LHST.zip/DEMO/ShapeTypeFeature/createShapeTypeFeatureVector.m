% Authors:	Lida LI, Lin ZHANG, Hongyu LI
% Date:       Oct. 4, 2014
% Email:      lld533@hotmail.com, cslinzhang@tongji.edu.cn
% VISCOM, School of Software Engineering, Tongji University, Shanghai,
% China.

function shapeTypeFeatureVector = createShapeTypeFeatureVector(shapeTypeImage, varargin)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% createShapeTypeFeatureVector creates Local Histogram Shape Type (LHST) feature 
% vector for a given ST image. The image will be uniformly split
% into m segments by row and n segments by column. 
% If the image can NOT be divided with NO remainder by row or by column,
% the center part will be extracted for computing. By default, m = n = 5.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Support:
%
%       shapeTypeFeatureVector = createShapeTypeFeatureVector(shapeTypeImage)
% or   shapeTypeFeatureVector = createShapeTypeFeatureVector(shapeTypeImage, m)
% or   shapeTypeFeatureVector = createShapeTypeFeatureVector(shapeTypeImage, m, n)
% or   shapeTypeFeatureVector = createShapeTypeFeatureVector(shapeTypeImage, [m, n])
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% constant value
nbin = 9;

%% parse input arguments
[m, n] = parseArguments(varargin);

%% compute indices for all patches
[STHeight, STWidth] = size(shapeTypeImage);
rowStep = floor( STHeight / double(m) );
columnStep = floor( STWidth / double(n) );

if verLessThan( 'matlab', '8.1' )
	rowStartPixel = floor((STHeight - rowStep * m)/2);
	columnStartPixel = floor((STWidth - columnStep * n)/2);
else
	rowStartPixel = bitshift( STHeight - rowStep * m , -1 );
	columnStartPixel = bitshift( STWidth - columnStep * n, -1 );
end

rowIndices = (1 + rowStartPixel) + 0:rowStep:(rowStep * (m + 1) );
columnIndices = (1 + columnStartPixel) + 0:columnStep:(columnStep * (n + 1) );

%% init variables for loop
currentPos = 0;
numHistograms = m * n;
shapeTypeFeatureVector = zeros( nbin * numHistograms, 1 );


%% histogram each patch and concatenate all histograms into the LHST feature vector
for i = 1:m
    for j = 1:n
        
        % move on to current patch
        currentPatch = shapeTypeImage( rowIndices(i):(rowIndices(i+1) - 1), columnIndices(j):(columnIndices(j+1) - 1) );
    
        % histogram current patch
        shapeTypeFeatureVector( (currentPos + 1):(currentPos + nbin) ) = hist(currentPatch(:), 1:nbin);
		
        % update current position of the LHST feature vector
		currentPos = currentPos + nbin;
        
    end
end

shapeTypeFeatureVector = double(shapeTypeFeatureVector) / double(rowStep * columnStep);

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%           Local Function: PARSEARGUMENTS
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Support varargin == [], m, or m,n, or [m, n]
% By default, m = n = 5;
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [m, n] = parseArguments(varargin)

m = 5;
n = 5;
        
switch(length(varargin{1}))
    case 1
        v = varargin{1}{1};
        
        if isvector(v)
            if length(v) == 1
                m = v(1);
                n = v(1);
            elseif length(v)>=2
                m  = v(1);
                n = v(2);
            end
        end
    case 2
        m = varargin{1}{1}(1);
        n = varargin{1}{2}(1);
    otherwise
        error('Invalid number of input arguments!');
end

m = max(1, uint8(m));
n = max(1, uint8(n));

end