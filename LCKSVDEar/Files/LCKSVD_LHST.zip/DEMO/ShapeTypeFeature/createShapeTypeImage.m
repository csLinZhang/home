% Authors:	Lida LI, Lin ZHANG, Hongyu LI
% Date:       Oct. 4, 2014
% Email:      lld533@hotmail.com, cslinzhang@tongji.edu.cn
% VISCOM, School of Software Engineering, Tongji University, Shanghai,
% China.

function STImage = createShapeTypeImage(rangeData, S, Du, Dv, Duu, Dvv, Duv, epsilonH, epsilonK)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                       Description
%
% createShapeTypeImage creates a Local Histogram Shape Type Image for a given normalized ear ROI range image.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

	smoothedVersion = conv2(rangeData, S, 'same');

	gu = conv2(smoothedVersion, Du, 'same');
	gv = conv2(smoothedVersion, Dv, 'same');
	guu = conv2(smoothedVersion, Duu, 'same');
	gvv = conv2(smoothedVersion, Dvv, 'same');
	guv = conv2(smoothedVersion, Duv, 'same');

	H = ((1+gv.^2).*guu + (1+gu.^2).*gvv - 2*gu.*gv.*guv) ./ (2 * (1+gu.^2+gv.^2).^(3/2));
	K = (guu.*gvv - guv.^2) ./ ((1+gu.^2+gv.^2).^2);

	%normalize the mean curvature and Gaussian curvature based on Wei Li's
	%paper.
	H = H / 2/ std(H(:));
	K = K / 2 / std(K(:));

	signH = zeros(size(H));
	signH(H > epsilonH) = 1;
	signH(H < -epsilonH) = -1;

	signK = zeros(size(K));
	signK(K > epsilonK) = 1;
	signK(K < -epsilonK) = -1;

	STImage = uint8( 1 + 3*(1+signH) + (1-signK) );

end