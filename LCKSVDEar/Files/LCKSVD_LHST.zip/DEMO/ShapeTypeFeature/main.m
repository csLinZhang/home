% Authors:	Lida LI, Lin ZHANG, Hongyu LI
% Date:       Sept. 14, 2014
% Email:      lld533@hotmail.com, cslinzhang@tongji.edu.cn
% VISCOM, School of Software Engineering, Tongji University, Shanghai,
% China.

function main()
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                       Description
%
% This demo demonstrate the procedures of generating a Shape Type Feature
% Vector from a normalized ear ROI.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear;
clc;

%% the file path of the normalized ear ROI file
ROIPath = './rangeImage.jpg';

%% constant values for creating Shape Type Image
s = 1/64 * [1 6 15 20 15 6 1]';
S = s * s';
d0 = 1/7 * [1 1 1 1 1 1 1]';
d1 = 1/28 * [-3 -2 -1 0 1 2 3]';
d2 = 1/84 * [5 0 -3 -4 -3 0 5]';
Du = d0 * d1';
Dv = d1 * d0';
Duu = d0 * d2';
Dvv = d2 * d0';
Duv = d1 * d1';
epsilonH = 0.030;
epsilonK = 0.015;

%% constant values for creating Shape Type Feature Vector
rowSegments = 9;
colSegments = 6;

%% Load range image
img = im2double( imread( ROIPath ) );

%% Create Shape Type Image
STImage = createShapeTypeImage( img, S, Du, Dv, Duu, Dvv, Duv, epsilonH, epsilonK );

%% Create LHST feature vector
shapeTypeFeatureVector = createShapeTypeFeatureVector(STImage, [rowSegments, colSegments]);

%% Save LHST feature vector
save( './shapeTypeFeatureVector.mat', 'shapeTypeFeatureVector' );
fprintf( 'Local Histogram Shape Type feature vector has been created successfully!\n' );
fprintf( 'The result can be found in ./shapeTypeFeatureVector.mat\n' );

end